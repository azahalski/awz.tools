<?
$arModuleVersion = array(
	"VERSION" => "1.0.3",
	"VERSION_DATE" => "2024-04-18 23:20:00"
);
?>