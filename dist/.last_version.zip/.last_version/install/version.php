<?
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2025-03-09 23:01:00"
);
?>