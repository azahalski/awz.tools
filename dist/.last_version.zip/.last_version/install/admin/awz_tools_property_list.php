<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.tools/admin/property_list.php");